<?php 

$version = time();

